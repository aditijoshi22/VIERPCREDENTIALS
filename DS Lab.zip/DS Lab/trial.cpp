// Write a program to keep track of patients as they checked into a medical clinic,assigning patients to doctors on a first-come, first-served basis.
#include <iostream>
using namespace std;
struct node
{
    string name;
    node *next;
};
node *createNode(string name)
{
    node *newNode = new node;
    newNode->name = name;
    newNode->next = NULL;
    return newNode;
}
void enqueue(node *&front, node *&rear, string name)
{
    node *newNode = createNode(name);
    if (rear == NULL)
    {
        front = rear = newNode;
    }
    else
    {
        rear->next = newNode;
        rear = newNode;
    }
}
string dequeue(node *&front, node *&rear)
{
    if (front == NULL)
    {
        return "No patients.";
    }
    string pname = front->name;
    node *temp = front;
    front = front->next;
    if (front == NULL)
    {
        rear = NULL;
    }
    delete temp;
    return pname;
}
bool isEmpty(node *front)
{
    return front == NULL;
}
int main()
{
    node *front = NULL;
    node *rear = NULL;
    enqueue(front, rear, "Aditi");
    enqueue(front, rear, "Rahul");
    enqueue(front, rear, "Meera");
    cout << "Assigned: " << dequeue(front, rear) << endl;
    cout << "Assigned: " << dequeue(front, rear) << endl;
    cout << "Assigned: " << dequeue(front, rear) << endl;
    cout << "Assigned: " << dequeue(front, rear) << endl;
    return 0;
}
